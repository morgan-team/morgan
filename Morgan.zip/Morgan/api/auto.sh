#!/bin/bash
COUNTER=1
while(true) do
./Morgan.sh
let COUNTER=COUNTER+1 
done

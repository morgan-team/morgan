#!/bin/bash
COUNTER=1
while(true) do
./Morgan.sh
done

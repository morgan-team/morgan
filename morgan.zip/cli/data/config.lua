do local _ = {
  admins = {},
  disabled_channels = {},
  enabled_plugins = {
    "BanHammer",
    "Fun",
    "GroupManager",
    "Msg-Checks",
    "Plugins",
    "Tools",
    "Write"
  },
  info_text = "\9》MaTaDoR BoT v5.7\nAn advanced administration bot based on https://valtman.name/telegram-cli\n\n》https://github.com/BeyondTeam/BDReborn \n\n》Admins :\n》@shiekhmamad ➣ Founder & Developer《\n》@shiekhmamadbot ➣ Developer《\n》@omidreza24 ➣ Developer《\n\n》Special thanks to :\n》MORGANTeaM\n\n》Our channel :\n》@MORGANTeam《\n",
  moderation = {
    data = "./data/moderation.json"
  },
  sudo_users = {
    476396377,
    4396377,
    463879916,
    467610784
  }
}
return _
end
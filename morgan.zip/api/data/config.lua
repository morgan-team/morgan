do local _ = {
  admins = {},
  disabled_channels = {},
  enabled_plugins = {
    "core",
    "plugins"
  },
  info_text = "*》MORGAN Helper Bot V1*\n\9\n》[MORGAN Helper](https://github.com/MORGANTeam/MORGAN)\n\n*》Admins :*\n*》Founder & Developer :* [MAMAD](Telegram.Me/SHIEKH_MAMAD)\n_》Developer :_ [JaVaD](Telegram.Me/SHIEKH_MAMAD_BOT)\n_》Developer & Sponser :_ [OMID](Telegram.Me/OMIDREZA24)\n\n*》Special thanks to :*\n》[MAMAD](Telegram.Me/SHIEKH_MAMAD)\n\n*》Our channel :*\n》[MORGANTeaM](Telegram.Me/MORGAN_Team)\n",
  moderation = {
    data = "/root/MaTaDoR/cli/data/moderation.json"
  },
  sudo_users = {
    476396377,
    476396377
  }
}
return _
end